package com.bankapp.model.dao;


public enum AccountType {
	SAVINGS, CURRENT;
}