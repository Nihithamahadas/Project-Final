package com.bankapp.model.dao.user;

public enum UserType {
	ADMIN, EMPLOYEE;
}