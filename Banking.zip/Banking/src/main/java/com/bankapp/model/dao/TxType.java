package com.bankapp.model.dao;

public enum TxType {
	
	WITHDRAW, DEPOSIT, TRANSFER;
	
}